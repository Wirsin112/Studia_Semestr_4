table = []
table.append(int(input("Wprowadz 1 liczbe\n")))
table.append(int(input("Wprowadz 2 liczbe\n")))
table.append(int(input("Wprowadz 3 liczbe\n")))
print(max(table))
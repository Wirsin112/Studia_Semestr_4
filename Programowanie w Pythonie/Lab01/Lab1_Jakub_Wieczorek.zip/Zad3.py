for i in range(ord('a'),ord('z')):
    mala = chr(i)
    duza = mala.upper()
    print(mala+" "+duza)